<?php
/**
 * The design guide ability, which hands agents that work on the site through
 * the Abilities API what Ipsum is built with and how it is meant to be used.
 *
 * @package Ipsum
 * @since Ipsum 1.0
 */

if ( ! function_exists( 'ipsum_register_abilities' ) ) :
	/**
	 * Registers the design guide ability, so agents that work on the site
	 * through the Abilities API, rather than this repository, can learn how
	 * Ipsum is meant to be built with.
	 *
	 * It needs `edit_theme_options`, the capability behind the Site Editor and
	 * Global Styles, since the guide is for whoever builds the site's design.
	 *
	 * @since Ipsum 1.0
	 *
	 * @return void
	 */
	function ipsum_register_abilities() {
		$output_schema = ipsum_get_design_guide_schema();

		wp_register_ability(
			'ipsum/get-design-guide',
			array(
				'label'                 => __( 'Get Design Guide', 'ipsum' ),
				'description'           => __( 'Returns the design guide of the Ipsum theme, read from the site as it is now. By default returns the basic design sections: the active theme, whether the palette is light or dark, the color palette and what each color is for, gradients, duotone, typography, spacing, layout widths, and guidelines. Pass fields to request specific sections, including larger lists such as style variations, block styles, patterns, templates, template parts, and template part areas. Read it before building pages, templates or styles.', 'ipsum' ),
				'category'              => 'site',
				'input_schema'          => array(
					'type'                 => 'object',
					'properties'           => array(
						'fields' => array(
							'type'        => 'array',
							'title'       => __( 'Fields', 'ipsum' ),
							'description' => __( 'Optional. Sections to return. When omitted or empty, returns the basic design sections (theme, colorScheme, colors, gradients, duotone, typography, spacing, layout, guidelines). When set, returns only the listed sections. Every section name in the enum is valid, including larger lists such as patterns, templates, template parts, template part areas, block styles, and style variations.', 'ipsum' ),
							'items'       => array(
								'type' => 'string',
								'enum' => array_keys( $output_schema['properties'] ),
							),
						),
					),
					'additionalProperties' => false,
					'default'              => array(),
				),
				'output_schema'         => $output_schema,
				'execute_callback'      => 'ipsum_get_design_guide',
				'required_capabilities' => array( 'edit_theme_options' ),
				'meta'                  => array(
					'annotations' => array(
						'readonly'    => true,
						'destructive' => false,
						'idempotent'  => true,
					),
					'public'      => true,
				),
			)
		);
	}
endif;
add_action( 'wp_abilities_api_init', 'ipsum_register_abilities' );

if ( ! function_exists( 'ipsum_get_color_roles' ) ) :
	/**
	 * Returns what each palette color is for, keyed by its slug.
	 *
	 * Every color variation redefines the same slugs, so the roles hold under
	 * whichever variation is active.
	 *
	 * @since Ipsum 1.0
	 *
	 * @return array<string, string> Role descriptions, keyed by palette slug.
	 */
	function ipsum_get_color_roles() {
		return array(
			'base'     => __( 'The page background.', 'ipsum' ),
			'contrast' => __( 'Body text, headings, links and buttons, on Base. It can be translucent, so on any other background use Strong Contrast.', 'ipsum' ),
			'accent-1' => __( 'An accent for small highlights. The theme uses it only for the arrival bar. Links and buttons use Contrast, not this. Use it sparingly.', 'ipsum' ),
			'accent-3' => __( 'The strongest contrast with the background, not an accent: hover states, and the background of inverted sections such as the navigation overlay, with Base for the text.', 'ipsum' ),
			'accent-5' => __( 'A subtle, translucent wash behind quotes, tags and table headers. It works on any background; keep Contrast text on it.', 'ipsum' ),
			'accent-6' => __( 'Faint, translucent lines, such as borders, list markers and table rules. Not for text.', 'ipsum' ),
		);
	}
endif;

if ( ! function_exists( 'ipsum_get_design_guide_default_fields' ) ) :
	/**
	 * Returns the design guide sections included when fields is omitted or empty.
	 *
	 * Larger lists (style variations, block styles, patterns, templates,
	 * template parts, and template part areas) are left out of the default
	 * response and must be requested through fields.
	 *
	 * @since Ipsum 1.0
	 *
	 * @return string[] Section names.
	 */
	function ipsum_get_design_guide_default_fields() {
		return array(
			'theme',
			'colorScheme',
			'colors',
			'gradients',
			'duotone',
			'typography',
			'spacing',
			'layout',
			'guidelines',
		);
	}
endif;

if ( ! function_exists( 'ipsum_get_design_guide_schema' ) ) :
	/**
	 * Returns the JSON Schema of the design guide, with one property per section.
	 *
	 * Top-level sections stay optional so callers can request a subset. Nested
	 * objects with a fixed set of fields mark guaranteed properties as required
	 * and set additionalProperties to false.
	 *
	 * @since Ipsum 1.0
	 *
	 * @return array<string, mixed> The output schema of the design guide ability.
	 * @phpstan-return array{
	 *     type: 'object',
	 *     additionalProperties: false,
	 *     properties: array<string, array<string, mixed>>
	 * }
	 */
	function ipsum_get_design_guide_schema() {
		$string   = array( 'type' => 'string' );
		$nullable = array(
			'type'        => array( 'string', 'null' ),
			'description' => __( 'A font family preset slug, a literal font-family value, or null when unset.', 'ipsum' ),
		);
		$strings  = array(
			'type'  => 'array',
			'items' => $string,
		);
		$scheme   = array(
			'type'        => 'string',
			'title'       => __( 'Color Scheme', 'ipsum' ),
			'description' => __( 'Whether the palette is light or dark.', 'ipsum' ),
			'enum'        => array( 'light', 'dark' ),
		);

		$object_list = static function ( $title, $description, $properties, $required = array() ) {
			$items = array(
				'type'                 => 'object',
				'properties'           => $properties,
				'additionalProperties' => false,
			);
			if ( ! empty( $required ) ) {
				$items['required'] = $required;
			}
			return array(
				'type'        => 'array',
				'title'       => $title,
				'description' => $description,
				'items'       => $items,
			);
		};

		$preset_list = static function ( $title, $description, $value_key, $value_schema, $required, $extra_properties = array() ) use ( $object_list ) {
			$name_description = in_array( 'name', $required, true )
				? __( 'The human-readable preset name.', 'ipsum' )
				: __( 'The human-readable preset name. Omitted when the preset does not set one.', 'ipsum' );
			$properties       = array_merge(
				array(
					'slug'     => array(
						'type'        => 'string',
						'title'       => __( 'Slug', 'ipsum' ),
						'description' => __( 'The preset slug.', 'ipsum' ),
					),
					'name'     => array(
						'type'        => 'string',
						'title'       => __( 'Name', 'ipsum' ),
						'description' => $name_description,
					),
					$value_key => $value_schema,
				),
				$extra_properties
			);
			return $object_list( $title, $description, $properties, $required );
		};

		$colors = $preset_list(
			__( 'Colors', 'ipsum' ),
			__( 'The color palette from the theme and any colors added on the site, with what each theme color is for. Every style variation redefines the same slugs. The role field is omitted for colors that have no known role.', 'ipsum' ),
			'color',
			array(
				'type'        => 'string',
				'title'       => __( 'Color', 'ipsum' ),
				'description' => __( 'The CSS color value.', 'ipsum' ),
			),
			array( 'slug', 'name', 'color' ),
			array(
				'role' => array(
					'type'        => 'string',
					'title'       => __( 'Role', 'ipsum' ),
					'description' => __( 'What the color is for. Present only for theme palette colors with a known role.', 'ipsum' ),
				),
			)
		);

		$font_value = array(
			'type'        => array( 'string', 'null' ),
			'description' => __( 'A font family preset slug, a literal font-family value, or null when unset. headingFont falls back to bodyFont when headings do not set their own family.', 'ipsum' ),
		);

		return array(
			'type'                 => 'object',
			'additionalProperties' => false,
			'properties'           => array(
				'theme'             => array(
					'type'                 => 'object',
					'title'                => __( 'Theme', 'ipsum' ),
					'description'          => __( 'The active theme. Its stylesheet is the one to use in REST routes such as /wp/v2/global-styles/themes/{stylesheet}.', 'ipsum' ),
					'properties'           => array(
						'name'       => array(
							'type'        => 'string',
							'title'       => __( 'Name', 'ipsum' ),
							'description' => __( 'The active theme name.', 'ipsum' ),
						),
						'stylesheet' => array(
							'type'        => 'string',
							'title'       => __( 'Stylesheet', 'ipsum' ),
							'description' => __( 'The theme stylesheet slug.', 'ipsum' ),
						),
					),
					'required'             => array( 'name', 'stylesheet' ),
					'additionalProperties' => false,
				),
				'colorScheme'       => array_merge(
					$scheme,
					array( 'description' => __( 'Whether the active palette is light or dark.', 'ipsum' ) )
				),
				'colors'            => $colors,
				'gradients'         => $preset_list(
					__( 'Gradients', 'ipsum' ),
					__( 'The gradient presets from the theme and any added on the site.', 'ipsum' ),
					'gradient',
					array(
						'type'        => 'string',
						'title'       => __( 'Gradient', 'ipsum' ),
						'description' => __( 'The CSS gradient value.', 'ipsum' ),
					),
					array( 'slug', 'name', 'gradient' )
				),
				'duotone'           => $preset_list(
					__( 'Duotone', 'ipsum' ),
					__( 'The duotone filter presets from the theme and any added on the site.', 'ipsum' ),
					'colors',
					array_merge(
						$strings,
						array(
							'title'       => __( 'Colors', 'ipsum' ),
							'description' => __( 'The two colors in the duotone filter.', 'ipsum' ),
						)
					),
					array( 'slug', 'name', 'colors' )
				),
				'typography'        => array(
					'type'                 => 'object',
					'title'                => __( 'Typography', 'ipsum' ),
					'description'          => __( 'The font families of body text and headings, the blocks that use another family, and the font family and font size presets. Font values are preset slugs, literal font-family values, or null. headingFont falls back to bodyFont when headings do not set their own family. Font size presets list theme sizes first, then any custom sizes; they are not sorted by size.', 'ipsum' ),
					'properties'           => array(
						'bodyFont'     => array_merge(
							$font_value,
							array( 'title' => __( 'Body Font', 'ipsum' ) )
						),
						'headingFont'  => array_merge(
							$font_value,
							array( 'title' => __( 'Heading Font', 'ipsum' ) )
						),
						'blockFonts'   => array(
							'type'                 => 'object',
							'title'                => __( 'Block Fonts', 'ipsum' ),
							'description'          => __( 'The blocks set in another font than body text, such as buttons, navigation and post meta, grouped by font family slug or literal value.', 'ipsum' ),
							'additionalProperties' => $strings,
						),
						'fontFamilies' => $preset_list(
							__( 'Font Families', 'ipsum' ),
							__( 'The font family presets from the theme and any added on the site. The name is omitted when a preset does not set one.', 'ipsum' ),
							'fontFamily',
							array(
								'type'        => 'string',
								'title'       => __( 'Font Family', 'ipsum' ),
								'description' => __( 'The CSS font-family value.', 'ipsum' ),
							),
							array( 'slug', 'fontFamily' )
						),
						'fontSizes'    => $preset_list(
							__( 'Font Sizes', 'ipsum' ),
							__( 'The font size presets from the theme, then any custom sizes. Not sorted by size. The name is omitted when a preset does not set one.', 'ipsum' ),
							'size',
							array(
								'type'        => 'string',
								'title'       => __( 'Size', 'ipsum' ),
								'description' => __( 'The CSS font-size value.', 'ipsum' ),
							),
							array( 'slug', 'size' )
						),
					),
					'required'             => array( 'bodyFont', 'headingFont', 'blockFonts', 'fontFamilies', 'fontSizes' ),
					'additionalProperties' => false,
				),
				'spacing'           => $preset_list(
					__( 'Spacing', 'ipsum' ),
					__( 'The spacing scale from the theme, then any custom sizes. Not sorted by size. The name is omitted when a preset does not set one.', 'ipsum' ),
					'size',
					array(
						'type'        => 'string',
						'title'       => __( 'Size', 'ipsum' ),
						'description' => __( 'The CSS spacing size value.', 'ipsum' ),
					),
					array( 'slug', 'size' )
				),
				'layout'            => array(
					'type'                 => 'object',
					'title'                => __( 'Layout', 'ipsum' ),
					'description'          => __( 'The width of the content, and of wide-aligned blocks.', 'ipsum' ),
					'properties'           => array(
						'contentSize' => array(
							'type'        => array( 'string', 'null' ),
							'title'       => __( 'Content Size', 'ipsum' ),
							'description' => __( 'The default content width, or null when unset.', 'ipsum' ),
						),
						'wideSize'    => array(
							'type'        => array( 'string', 'null' ),
							'title'       => __( 'Wide Size', 'ipsum' ),
							'description' => __( 'The wide-aligned content width, or null when unset.', 'ipsum' ),
						),
					),
					'required'             => array( 'contentSize', 'wideSize' ),
					'additionalProperties' => false,
				),
				'styleVariations'   => $object_list(
					__( 'Style Variations', 'ipsum' ),
					__( 'The style variations available for this theme. Each item lists only what that variation changes: colorScheme and colors for the palette, bodyFont and headingFont for the fonts, and blocks for the style properties it sets on each block. Optional fields are omitted when the variation does not change them. Their full data is at /wp/v2/global-styles/themes/{stylesheet}/variations.', 'ipsum' ),
					array(
						'title'       => array(
							'type'        => 'string',
							'title'       => __( 'Title', 'ipsum' ),
							'description' => __( 'The style variation title.', 'ipsum' ),
						),
						'colorScheme' => $scheme,
						'colors'      => array(
							'type'                 => 'object',
							'title'                => __( 'Colors', 'ipsum' ),
							'description'          => __( 'Palette colors the variation sets, keyed by slug.', 'ipsum' ),
							'additionalProperties' => $string,
						),
						'bodyFont'    => array_merge(
							$nullable,
							array( 'title' => __( 'Body Font', 'ipsum' ) )
						),
						'headingFont' => array_merge(
							$nullable,
							array( 'title' => __( 'Heading Font', 'ipsum' ) )
						),
						'blocks'      => array(
							'type'                 => 'object',
							'title'                => __( 'Blocks', 'ipsum' ),
							'description'          => __( 'Style property names the variation sets on each block, keyed by block name.', 'ipsum' ),
							'additionalProperties' => $strings,
						),
					),
					array( 'title' )
				),
				'blockStyles'       => $object_list(
					__( 'Block Styles', 'ipsum' ),
					__( 'The block styles registered on this site, beyond the ones blocks define themselves. Add className to a block of one of the blockTypes to apply it.', 'ipsum' ),
					array(
						'name'       => array(
							'type'        => 'string',
							'title'       => __( 'Name', 'ipsum' ),
							'description' => __( 'The block style slug.', 'ipsum' ),
						),
						'label'      => array(
							'type'        => 'string',
							'title'       => __( 'Label', 'ipsum' ),
							'description' => __( 'The human-readable block style label.', 'ipsum' ),
						),
						'className'  => array(
							'type'        => 'string',
							'title'       => __( 'Class Name', 'ipsum' ),
							'description' => __( 'The CSS class to add to the block, such as is-style-outline.', 'ipsum' ),
						),
						'blockTypes' => array_merge(
							$strings,
							array(
								'title'       => __( 'Block Types', 'ipsum' ),
								'description' => __( 'The block names this style can be applied to.', 'ipsum' ),
							)
						),
					),
					array( 'name', 'label', 'className', 'blockTypes' )
				),
				'patterns'          => $object_list(
					__( 'Patterns', 'ipsum' ),
					__( 'The patterns registered by the active theme, without their markup, which is at /wp/v2/block-patterns/patterns. Includes both insertable patterns and hidden ones that fill templates and template parts. Optional fields (blockTypes, templateTypes, postTypes) are omitted when empty.', 'ipsum' ),
					array(
						'slug'          => array(
							'type'        => 'string',
							'title'       => __( 'Slug', 'ipsum' ),
							'description' => __( 'The pattern slug.', 'ipsum' ),
						),
						'title'         => array(
							'type'        => 'string',
							'title'       => __( 'Title', 'ipsum' ),
							'description' => __( 'The pattern title.', 'ipsum' ),
						),
						'description'   => array(
							'type'        => 'string',
							'title'       => __( 'Description', 'ipsum' ),
							'description' => __( 'The pattern description.', 'ipsum' ),
						),
						'categories'    => array_merge(
							$strings,
							array(
								'title'       => __( 'Categories', 'ipsum' ),
								'description' => __( 'Pattern categories for the inserter.', 'ipsum' ),
							)
						),
						'blockTypes'    => array_merge(
							$strings,
							array(
								'title'       => __( 'Block Types', 'ipsum' ),
								'description' => __( 'Block types this pattern is associated with, such as for the block transformer. Omitted when empty.', 'ipsum' ),
							)
						),
						'templateTypes' => array_merge(
							$strings,
							array(
								'title'       => __( 'Template Types', 'ipsum' ),
								'description' => __( 'Template types this pattern is meant to fill. Omitted when empty.', 'ipsum' ),
							)
						),
						'postTypes'     => array_merge(
							$strings,
							array(
								'title'       => __( 'Post Types', 'ipsum' ),
								'description' => __( 'Limits which post types the pattern is available for. Omitted when empty.', 'ipsum' ),
							)
						),
						'hidden'        => array(
							'type'        => 'boolean',
							'title'       => __( 'Hidden', 'ipsum' ),
							'description' => __( 'Whether the pattern is excluded from the inserter. Hidden does not mean private; these patterns typically fill templates and template parts.', 'ipsum' ),
						),
					),
					array( 'slug', 'title', 'description', 'categories', 'hidden' )
				),
				'templates'         => $object_list(
					__( 'Templates', 'ipsum' ),
					__( 'The block templates available on the site, including theme templates and any customized copies, with the pattern each delegates to when its markup is a single Pattern block.', 'ipsum' ),
					array(
						'slug'        => array(
							'type'        => 'string',
							'title'       => __( 'Slug', 'ipsum' ),
							'description' => __( 'The template slug.', 'ipsum' ),
						),
						'title'       => array(
							'type'        => 'string',
							'title'       => __( 'Title', 'ipsum' ),
							'description' => __( 'The template title.', 'ipsum' ),
						),
						'description' => array(
							'type'        => 'string',
							'title'       => __( 'Description', 'ipsum' ),
							'description' => __( 'The template description.', 'ipsum' ),
						),
						'pattern'     => array(
							'type'        => array( 'string', 'null' ),
							'title'       => __( 'Pattern', 'ipsum' ),
							'description' => __( 'The pattern slug when the template markup is a single Pattern block, otherwise null. A customized template can still reference a pattern.', 'ipsum' ),
						),
						'customized'  => array(
							'type'        => 'boolean',
							'title'       => __( 'Customized', 'ipsum' ),
							'description' => __( 'Whether the template has a saved customization on this site.', 'ipsum' ),
						),
						'postTypes'   => array_merge(
							$strings,
							array(
								'title'       => __( 'Post Types', 'ipsum' ),
								'description' => __( 'Post types the template applies to. Omitted when empty.', 'ipsum' ),
							)
						),
					),
					array( 'slug', 'title', 'description', 'pattern', 'customized' )
				),
				'templateParts'     => $object_list(
					__( 'Template Parts', 'ipsum' ),
					__( 'The template parts available on the site, including theme parts and any customized copies, with their area and the pattern each delegates to when its markup is a single Pattern block.', 'ipsum' ),
					array(
						'slug'       => array(
							'type'        => 'string',
							'title'       => __( 'Slug', 'ipsum' ),
							'description' => __( 'The template part slug.', 'ipsum' ),
						),
						'title'      => array(
							'type'        => 'string',
							'title'       => __( 'Title', 'ipsum' ),
							'description' => __( 'The template part title.', 'ipsum' ),
						),
						'area'       => array(
							'type'        => array( 'string', 'null' ),
							'title'       => __( 'Area', 'ipsum' ),
							'description' => __( 'The template part area, such as header, footer, or uncategorized, or null when the part has no area term.', 'ipsum' ),
						),
						'pattern'    => array(
							'type'        => array( 'string', 'null' ),
							'title'       => __( 'Pattern', 'ipsum' ),
							'description' => __( 'The pattern slug when the template part markup is a single Pattern block, otherwise null. A customized template part can still reference a pattern.', 'ipsum' ),
						),
						'customized' => array(
							'type'        => 'boolean',
							'title'       => __( 'Customized', 'ipsum' ),
							'description' => __( 'Whether the template part has a saved customization on this site.', 'ipsum' ),
						),
					),
					array( 'slug', 'title', 'area', 'pattern', 'customized' )
				),
				'templatePartAreas' => $object_list(
					__( 'Template Part Areas', 'ipsum' ),
					__( 'The areas a template part can belong to on this site.', 'ipsum' ),
					array(
						'area'        => array(
							'type'        => 'string',
							'title'       => __( 'Area', 'ipsum' ),
							'description' => __( 'The template part area slug.', 'ipsum' ),
						),
						'label'       => array(
							'type'        => 'string',
							'title'       => __( 'Label', 'ipsum' ),
							'description' => __( 'The human-readable area label.', 'ipsum' ),
						),
						'description' => array(
							'type'        => 'string',
							'title'       => __( 'Description', 'ipsum' ),
							'description' => __( 'What the area is for.', 'ipsum' ),
						),
					),
					array( 'area', 'label', 'description' )
				),
				'guidelines'        => array(
					'type'        => 'array',
					'title'       => __( 'Guidelines', 'ipsum' ),
					'description' => __( 'How the theme is meant to be built with.', 'ipsum' ),
					'items'       => $string,
				),
			),
		);
	}
endif;

if ( ! function_exists( 'ipsum_get_design_guide_presets' ) ) :
	/**
	 * Lists the theme's presets of one kind, followed by any the site adds.
	 *
	 * @since Ipsum 1.0
	 *
	 * @param mixed    $presets The presets from the global settings, keyed by origin.
	 *                          Anything other than an array gives an empty list.
	 * @param string[] $keys    The preset properties to keep.
	 * @return array<int, array<string, mixed>> The presets, with only the given properties. Empty when
	 *                                          `$presets` isn't an array.
	 */
	function ipsum_get_design_guide_presets( $presets, $keys ) {
		$items = array();
		if ( ! is_array( $presets ) ) {
			return $items;
		}
		foreach ( array( 'theme', 'custom' ) as $origin ) {
			if ( ! isset( $presets[ $origin ] ) || ! is_array( $presets[ $origin ] ) ) {
				continue;
			}
			foreach ( $presets[ $origin ] as $preset ) {
				if ( ! is_array( $preset ) ) {
					continue;
				}
				$item = array();
				foreach ( $keys as $key ) {
					if ( isset( $preset[ $key ] ) ) {
						$item[ $key ] = $preset[ $key ];
					}
				}
				$items[] = $item;
			}
		}
		return $items;
	}
endif;

if ( ! function_exists( 'ipsum_get_design_guide_font_slug' ) ) :
	/**
	 * Returns the slug of the font family preset a style refers to.
	 *
	 * @since Ipsum 1.0
	 *
	 * @param mixed $font_family A fontFamily style value.
	 * @return string|null The preset slug, the value itself when it is not a
	 *                     preset, or null when there is no value.
	 */
	function ipsum_get_design_guide_font_slug( $font_family ) {
		if ( ! is_string( $font_family ) || '' === $font_family ) {
			return null;
		}
		if ( preg_match( '/^var(?::preset\|font-family\||\(--wp--preset--font-family--)([a-z0-9-]+)\)?$/', $font_family, $matches ) ) {
			return $matches[1];
		}
		return $font_family;
	}
endif;

if ( ! function_exists( 'ipsum_get_design_guide_pattern_slug' ) ) :
	/**
	 * Returns the pattern a template or template part delegates to.
	 *
	 * @since Ipsum 1.0
	 *
	 * @param string $content The template or template part markup.
	 * @return string|null The pattern slug, or null when the markup is not a
	 *                     single Pattern block.
	 */
	function ipsum_get_design_guide_pattern_slug( $content ) {
		$blocks = array_values(
			array_filter(
				parse_blocks( (string) $content ),
				static function ( $block ) {
					return null !== $block['blockName'];
				}
			)
		);
		if ( 1 === count( $blocks ) && 'core/pattern' === $blocks[0]['blockName'] && isset( $blocks[0]['attrs']['slug'] ) && is_string( $blocks[0]['attrs']['slug'] ) && '' !== $blocks[0]['attrs']['slug'] ) {
			return $blocks[0]['attrs']['slug'];
		}
		return null;
	}
endif;

if ( ! function_exists( 'ipsum_get_design_guide' ) ) :
	/**
	 * Builds the design guide from the site as it is, so it follows the active
	 * style variation and any change made in Global Styles or the Site Editor.
	 *
	 * @since Ipsum 1.0
	 *
	 * @param array $input {
	 *     The ability input.
	 *
	 *     @type string[] $fields Optional. The sections to return. When omitted
	 *                            or empty, returns the basic design sections
	 *                            from ipsum_get_design_guide_default_fields().
	 * }
	 * @return array<string, mixed> The design guide, keyed by section.
	 */
	function ipsum_get_design_guide( $input = array() ) {
		$all_sections = array_keys( ipsum_get_design_guide_schema()['properties'] );
		if ( ! empty( $input['fields'] ) ) {
			$sections = array_values( array_intersect( $all_sections, $input['fields'] ) );
		} else {
			$sections = ipsum_get_design_guide_default_fields();
		}
		$sections = array_flip( $sections );

		// Resolving the merged data also registers the block styles in styles/blocks.
		$settings = wp_get_global_settings();
		$styles   = wp_get_global_styles();
		$guide    = array();

		if ( isset( $sections['theme'] ) ) {
			$guide['theme'] = array(
				'name'       => wp_get_theme()->get( 'Name' ),
				'stylesheet' => get_stylesheet(),
			);
		}

		if ( isset( $sections['colorScheme'] ) ) {
			// The audio player's CSS also reads a palette that sets no scheme as light.
			$guide['colorScheme'] = 'dark' === ( $settings['custom']['controlScheme'] ?? '' ) ? 'dark' : 'light';
		}

		if ( isset( $sections['colors'] ) ) {
			$roles           = ipsum_get_color_roles();
			$guide['colors'] = array();
			foreach ( ipsum_get_design_guide_presets( $settings['color']['palette'] ?? array(), array( 'slug', 'name', 'color' ) ) as $color ) {
				if ( isset( $color['slug'] ) && is_string( $color['slug'] ) && isset( $roles[ $color['slug'] ] ) ) {
					$color['role'] = $roles[ $color['slug'] ];
				}
				$guide['colors'][] = $color;
			}
		}

		if ( isset( $sections['gradients'] ) ) {
			$guide['gradients'] = ipsum_get_design_guide_presets( $settings['color']['gradients'] ?? array(), array( 'slug', 'name', 'gradient' ) );
		}

		if ( isset( $sections['duotone'] ) ) {
			$guide['duotone'] = ipsum_get_design_guide_presets( $settings['color']['duotone'] ?? array(), array( 'slug', 'name', 'colors' ) );
		}

		if ( isset( $sections['typography'] ) ) {
			$body_font   = ipsum_get_design_guide_font_slug( $styles['typography']['fontFamily'] ?? '' );
			$block_fonts = array();
			$blocks      = $styles['blocks'] ?? null;
			foreach ( is_array( $blocks ) ? $blocks : array() as $block_type => $block_styles ) {
				$block_font = ipsum_get_design_guide_font_slug( $block_styles['typography']['fontFamily'] ?? '' );
				if ( null !== $block_font && $block_font !== $body_font ) {
					$block_fonts[ $block_font ][] = $block_type;
				}
			}
			$guide['typography'] = array(
				'bodyFont'     => $body_font,
				'headingFont'  => ipsum_get_design_guide_font_slug( $styles['elements']['heading']['typography']['fontFamily'] ?? '' ) ?? $body_font,
				'blockFonts'   => $block_fonts,
				'fontFamilies' => ipsum_get_design_guide_presets( $settings['typography']['fontFamilies'] ?? array(), array( 'slug', 'name', 'fontFamily' ) ),
				'fontSizes'    => ipsum_get_design_guide_presets( $settings['typography']['fontSizes'] ?? array(), array( 'slug', 'name', 'size' ) ),
			);
		}

		if ( isset( $sections['spacing'] ) ) {
			$guide['spacing'] = ipsum_get_design_guide_presets( $settings['spacing']['spacingSizes'] ?? array(), array( 'slug', 'name', 'size' ) );
		}

		if ( isset( $sections['layout'] ) ) {
			$guide['layout'] = array(
				'contentSize' => $settings['layout']['contentSize'] ?? null,
				'wideSize'    => $settings['layout']['wideSize'] ?? null,
			);
		}

		if ( isset( $sections['styleVariations'] ) ) {
			$guide['styleVariations'] = array();
			foreach ( WP_Theme_JSON_Resolver::get_style_variations() as $variation ) {
				$variation_settings = $variation['settings'] ?? array();
				$variation_styles   = $variation['styles'] ?? array();
				$item               = array( 'title' => $variation['title'] );

				if ( isset( $variation_settings['custom']['controlScheme'] ) ) {
					$item['colorScheme'] = 'dark' === $variation_settings['custom']['controlScheme'] ? 'dark' : 'light';
				}
				if ( ! empty( $variation_settings['color']['palette'] ) ) {
					$item['colors'] = array_column( ipsum_get_design_guide_presets( $variation_settings['color']['palette'], array( 'slug', 'color' ) ), 'color', 'slug' );
				}
				if ( ! empty( $variation_styles['typography']['fontFamily'] ) ) {
					$item['bodyFont'] = ipsum_get_design_guide_font_slug( $variation_styles['typography']['fontFamily'] );
				}
				if ( ! empty( $variation_styles['elements']['heading']['typography']['fontFamily'] ) ) {
					$item['headingFont'] = ipsum_get_design_guide_font_slug( $variation_styles['elements']['heading']['typography']['fontFamily'] );
				}
				if ( ! empty( $variation_styles['blocks'] ) && is_array( $variation_styles['blocks'] ) ) {
					$item['blocks'] = array_map(
						static function ( $block_styles ) {
							return is_array( $block_styles ) ? array_keys( $block_styles ) : array();
						},
						$variation_styles['blocks']
					);
				}
				$guide['styleVariations'][] = $item;
			}
		}

		if ( isset( $sections['blockStyles'] ) ) {
			$block_styles = array();
			foreach ( WP_Block_Styles_Registry::get_instance()->get_all_registered() as $block_type => $block_type_styles ) {
				foreach ( $block_type_styles as $name => $style ) {
					if ( ! isset( $block_styles[ $name ] ) ) {
						$block_styles[ $name ] = array(
							'name'       => $name,
							'label'      => $style['label'] ?? $name,
							'className'  => 'is-style-' . $name,
							'blockTypes' => array(),
						);
					}
					$block_styles[ $name ]['blockTypes'][] = $block_type;
				}
			}
			$guide['blockStyles'] = array_values( $block_styles );
		}

		if ( isset( $sections['patterns'] ) ) {
			// Look up the theme's patterns by slug, since the registry drops a pattern's filePath once its content is loaded.
			$theme               = wp_get_theme();
			$theme_pattern_slugs = array();
			foreach ( array_filter( array( $theme, $theme->parent() ) ) as $pattern_theme ) {
				foreach ( $pattern_theme->get_block_patterns() as $file_pattern ) {
					if ( isset( $file_pattern['slug'] ) && is_string( $file_pattern['slug'] ) ) {
						$theme_pattern_slugs[] = $file_pattern['slug'];
					}
				}
			}

			$registry          = WP_Block_Patterns_Registry::get_instance();
			$guide['patterns'] = array();
			foreach ( array_unique( $theme_pattern_slugs ) as $slug ) {
				$pattern = $registry->get_registered( $slug );
				if ( null === $pattern ) {
					continue;
				}
				$item = array(
					'slug'        => $pattern['name'],
					'title'       => $pattern['title'],
					'description' => $pattern['description'] ?? '',
					'categories'  => $pattern['categories'] ?? array(),
				);
				foreach ( array( 'blockTypes', 'templateTypes', 'postTypes' ) as $key ) {
					if ( ! empty( $pattern[ $key ] ) ) {
						$item[ $key ] = $pattern[ $key ];
					}
				}
				$item['hidden']      = isset( $pattern['inserter'] ) && ! $pattern['inserter'];
				$guide['patterns'][] = $item;
			}
		}

		foreach ( array(
			'templates'     => 'wp_template',
			'templateParts' => 'wp_template_part',
		) as $section => $template_type ) {
			if ( ! isset( $sections[ $section ] ) ) {
				continue;
			}
			$guide[ $section ] = array();
			foreach ( get_block_templates( array(), $template_type ) as $template ) {
				$item = array(
					'slug'  => $template->slug,
					'title' => $template->title,
				);
				if ( 'wp_template' === $template_type ) {
					$item['description'] = (string) $template->description;
				} else {
					$item['area'] = $template->area;
				}
				$item['pattern']    = ipsum_get_design_guide_pattern_slug( $template->content );
				$item['customized'] = 'custom' === $template->source;
				if ( ! empty( $template->post_types ) ) {
					$item['postTypes'] = $template->post_types;
				}
				$guide[ $section ][] = $item;
			}
		}

		if ( isset( $sections['templatePartAreas'] ) ) {
			$guide['templatePartAreas'] = array();
			foreach ( get_allowed_block_template_part_areas() as $area ) {
				$guide['templatePartAreas'][] = array(
					'area'        => $area['area'],
					'label'       => $area['label'],
					'description' => $area['description'],
				);
			}
		}

		if ( isset( $sections['guidelines'] ) ) {
			$guide['guidelines'] = array(
				__( 'Style with the presets in this guide, by slug, rather than with literal values. Every style variation redefines the colors, so a literal color keeps the look of one variation under all the others.', 'ipsum' ),
				__( 'Each template and template part holds a single Pattern block, and that pattern holds the markup. To change one on this site, save new markup to the template or template part itself.', 'ipsum' ),
				__( 'Hidden patterns are there to fill templates and template parts, not to be inserted on their own.', 'ipsum' ),
			);
		}

		return $guide;
	}
endif;
