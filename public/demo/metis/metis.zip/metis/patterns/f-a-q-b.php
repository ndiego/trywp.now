<?php
/**
 * Title: Selected work, accordion list
 * Slug: metis/f-a-q-b
 * Categories: portfolio
 * Description: A reflective opening line over an expandable accordion of long-running work.
 */
?>
<!-- wp:group {"tagName":"section","metadata":{"name":"Selected work, accordion list","description":"A reflective opening line over an expandable timeline of long-running work."},"align":"wide","style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70"}}},"layout":{"type":"constrained"},"anchor":"the-long-work"} -->
<section class="wp-block-group alignwide" id="the-long-work" style="padding-top:var(--wp--preset--spacing--70);padding-bottom:var(--wp--preset--spacing--70)"><!-- wp:columns {"verticalAlignment":"top","align":"wide"} -->
<div class="wp-block-columns alignwide are-vertically-aligned-top"><!-- wp:column {"verticalAlignment":"top","width":"35%","layout":{"type":"constrained","justifyContent":"left"}} -->
<div class="wp-block-column is-vertically-aligned-top" style="flex-basis:35%"><!-- wp:group {"metadata":{"name":"Column Stack"},"align":"wide","style":{"spacing":{"blockGap":{"top":"var:preset|spacing|30"}}},"layout":{"type":"flex","orientation":"vertical","justifyContent":"stretch"}} -->
<div class="wp-block-group alignwide"><!-- wp:heading {"align":"wide"} -->
<h2 class="wp-block-heading alignwide"><?php esc_html_e('Selected work', 'metis');?></h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"style":{"typography":{"fontStyle":"normal","fontWeight":"600"}},"fontFamily":"openrunde"} -->
<p class="has-openrunde-font-family" style="font-style:normal;font-weight:600"><?php esc_html_e('None of it was planned. Looking back, it makes a kind of line—the same few questions, asked in different weather.', 'metis');?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"top","width":"15%","layout":{"type":"constrained","justifyContent":"left"}} -->
<div class="wp-block-column is-vertically-aligned-top" style="flex-basis:15%"></div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"top","width":"50%"} -->
<div class="wp-block-column is-vertically-aligned-top" style="flex-basis:50%"><!-- wp:group {"metadata":{"name":"Timeline"},"align":"wide","style":{"spacing":{"blockGap":"var:preset|spacing|30"}},"layout":{"type":"default"}} -->
<div class="wp-block-group alignwide"><!-- wp:accordion {"style":{"spacing":{"blockGap":"0"}}} -->
<div role="group" class="wp-block-accordion"><!-- wp:accordion-item {"openByDefault":true,"style":{"spacing":{"blockGap":"var:preset|spacing|20","margin":{"top":"0","bottom":"0"}},"border":{"top":{"width":"1px","style":"dotted"}}}} -->
<div class="wp-block-accordion-item is-open" style="border-top-style:dotted;border-top-width:1px;margin-top:0;margin-bottom:0"><!-- wp:accordion-heading {"fontSize":"medium"} -->
<h3 class="wp-block-accordion-heading has-icon has-icon-right has-medium-font-size"><button type="button" class="wp-block-accordion-heading__toggle"><span class="wp-block-accordion-heading__toggle-title"><?php esc_html_e('2019 · The Ground Truth Archive', 'metis');?></span><span class="wp-block-accordion-heading__toggle-icon" aria-hidden="true">+</span></button></h3>
<!-- /wp:accordion-heading -->

<!-- wp:accordion-panel {"style":{"spacing":{"padding":{"bottom":"var:preset|spacing|60"}}}} -->
<div role="region" class="wp-block-accordion-panel" style="padding-bottom:var(--wp--preset--spacing--60)"><!-- wp:paragraph -->
<p><?php esc_html_e('Keeper. Hand-drawn maps, mine and other people’s, kept for the notes in their margins more than the lines themselves.', 'metis');?></p>
<!-- /wp:paragraph -->

<!-- wp:image {"sizeSlug":"full","linkDestination":"none","style":{"border":{"radius":{"topLeft":"5px","topRight":"5px","bottomLeft":"5px","bottomRight":"5px"}}}} -->
<figure class="wp-block-image size-full has-custom-border"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/assets/images/metis-artifact--app-design.webp" alt="<?php esc_attr_e('Two phones showing the Wend app: its wordmark over a warm photo, and a project screen with a note to self', 'metis');?>" class="" style="border-top-left-radius:5px;border-top-right-radius:5px;border-bottom-left-radius:5px;border-bottom-right-radius:5px"/></figure>
<!-- /wp:image --></div>
<!-- /wp:accordion-panel --></div>
<!-- /wp:accordion-item -->

<!-- wp:accordion-item {"style":{"spacing":{"blockGap":"var:preset|spacing|20","margin":{"top":"0","bottom":"0"}},"border":{"top":{"width":"1px","style":"dotted"}}}} -->
<div class="wp-block-accordion-item" style="border-top-style:dotted;border-top-width:1px;margin-top:0;margin-bottom:0"><!-- wp:accordion-heading {"fontSize":"medium"} -->
<h3 class="wp-block-accordion-heading has-icon has-icon-right has-medium-font-size"><button type="button" class="wp-block-accordion-heading__toggle"><span class="wp-block-accordion-heading__toggle-title"><?php esc_html_e('2011 · The Marginal Notes', 'metis');?></span><span class="wp-block-accordion-heading__toggle-icon" aria-hidden="true">+</span></button></h3>
<!-- /wp:accordion-heading -->

<!-- wp:accordion-panel {"style":{"spacing":{"padding":{"bottom":"var:preset|spacing|60"}}}} -->
<div role="region" class="wp-block-accordion-panel" style="padding-bottom:var(--wp--preset--spacing--60)"><!-- wp:paragraph -->
<p><?php esc_html_e('Columnist. One page in Almanac each month: whatever that month\'s walking shook loose, written down plainly and let go.', 'metis');?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:accordion-panel --></div>
<!-- /wp:accordion-item -->

<!-- wp:accordion-item {"style":{"spacing":{"blockGap":"var:preset|spacing|20","margin":{"top":"0","bottom":"0"}},"border":{"top":{"width":"1px","style":"dotted"}}}} -->
<div class="wp-block-accordion-item" style="border-top-style:dotted;border-top-width:1px;margin-top:0;margin-bottom:0"><!-- wp:accordion-heading {"fontSize":"medium"} -->
<h3 class="wp-block-accordion-heading has-icon has-icon-right has-medium-font-size"><button type="button" class="wp-block-accordion-heading__toggle"><span class="wp-block-accordion-heading__toggle-title"><?php esc_html_e('2004 · The Long Walk Society', 'metis');?></span><span class="wp-block-accordion-heading__toggle-icon" aria-hidden="true">+</span></button></h3>
<!-- /wp:accordion-heading -->

<!-- wp:accordion-panel {"style":{"spacing":{"padding":{"bottom":"var:preset|spacing|60"}}}} -->
<div role="region" class="wp-block-accordion-panel" style="padding-bottom:var(--wp--preset--spacing--60)"><!-- wp:paragraph -->
<p><?php esc_html_e('Secretary. A small society with one rule—walk far enough that the writing has to happen where you stop. The minutes slowly became essays.', 'metis');?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:accordion-panel --></div>
<!-- /wp:accordion-item -->

<!-- wp:accordion-item {"style":{"spacing":{"blockGap":"var:preset|spacing|20","margin":{"top":"0","bottom":"0"}},"border":{"top":{"width":"1px","style":"dotted"}}}} -->
<div class="wp-block-accordion-item" style="border-top-style:dotted;border-top-width:1px;margin-top:0;margin-bottom:0"><!-- wp:accordion-heading {"fontSize":"medium"} -->
<h3 class="wp-block-accordion-heading has-icon has-icon-right has-medium-font-size"><button type="button" class="wp-block-accordion-heading__toggle"><span class="wp-block-accordion-heading__toggle-title"><?php esc_html_e('1996-2016 · The Coast Survey', 'metis');?></span><span class="wp-block-accordion-heading__toggle-icon" aria-hidden="true">+</span></button></h3>
<!-- /wp:accordion-heading -->

<!-- wp:accordion-panel {"style":{"spacing":{"padding":{"bottom":"var:preset|spacing|60"}}}} -->
<div role="region" class="wp-block-accordion-panel" style="padding-bottom:var(--wp--preset--spacing--60)"><!-- wp:paragraph -->
<p><?php esc_html_e('Field writer. Twenty years on the national shoreline survey. The lines went to the cartographers; the sentences stayed with me.', 'metis');?></p>
<!-- /wp:paragraph --></div>
<!-- /wp:accordion-panel --></div>
<!-- /wp:accordion-item --></div>
<!-- /wp:accordion --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></section>
<!-- /wp:group -->
